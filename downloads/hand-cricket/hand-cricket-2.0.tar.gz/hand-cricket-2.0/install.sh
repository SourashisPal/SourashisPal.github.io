#!/usr/bin/bash
if [ `whoami` != "root" ]
then
	echo -e "\e[1;31mPlease run the installer in super-user mode\e[0m"
	exit
fi
if [ -d /usr/local/share/hand-cricket ]
then
	rm -r /usr/local/share/hand-cricket
fi
if [ -f /usr/local/share/applications/in.sourashis.handcricket.desktop ]
then
	rm /usr/local/share/applications/in.sourashis.handcricket.desktop
fi
mkdir /usr/local/share/hand-cricket
mv runtime /usr/local/share/hand-cricket/runtime
mv hand-cricket-2.0.jar /usr/local/share/hand-cricket
mv icon.png /usr/local/share/hand-cricket
mv in.sourashis.handcricket.desktop /usr/local/share/applications
mv uninstall.sh /usr/local/share/hand-cricket
rm install.sh
rmdir $(pwd)
echo -e "\e[1;32mHand Cricket installed successfully\e[0m"
