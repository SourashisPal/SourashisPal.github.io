#!/usr/bin/bash
if [ `whoami` != "root" ]
then
        echo -e "\e[1;31mPlease run the installer in super-user mode\e[0m"
        exit
fi
if [ -d /usr/local/share/hand-cricket ]
then
        rm -r /usr/local/share/hand-cricket
fi
if [ -f /usr/local/share/applications/in.sourashis.handcricket.desktop ]
then
        rm /usr/local/share/applications/in.sourashis.handcricket.desktop
fi
echo =e "\e[1;32mHand Cricket uninstalled successfully"
